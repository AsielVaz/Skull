<?php

class conector
{

    private $servername;
    private $database;
    private $username;
    private $password;

    public function __construct()
    {

        $this->servername = "localhost";
        $this->database = "efkrbqad_mascotas";
        $this->username = "efkrbqad_mascotas";
        $this->password = "Mascotas2022$$*";
        $this->apikeycaptcha = "6Ld_OMkfAAAAAGgJ7YfM11KUtKjLaoC-lRnyBetY";
    }
    public function ejecutar($query)
    {
        $conn = mysqli_connect($this->servername, $this->username, $this->password, $this->database);
        if (!$conn) {
            die("No se pudo conectar devido a: " . mysqli_connect_error());
        }
        $result = mysqli_query($conn, $query);
        return $result;
    }
}
