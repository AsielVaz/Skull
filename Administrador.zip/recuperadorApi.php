<?php

use PHPMailer\PHPMailer\PHPMailer;

function mailer($mail_destino, $nombre_destino, $asunto, $mensaje, $attachment, $attachment_name, $mail_oculto)
{
  $mail_host = 'mail.tcs.mx';
  $smtp_secure = 'tls';
  $mail_port = 587;
  $mail_email = 'noreply@solomascotas.mx';
  $mail_password = 'SoloMascotas2022$$';
  $mail_username = 'Beddy Mascotas';

  //Import PHPMailer classes into the global namespace
  require_once 'mailer/src/PHPMailer.php';
  require_once 'mailer/src/SMTP.php';
  require_once 'mailer/src/Exception.php';
  //Create a new PHPMailer instance
  $mail = new PHPMailer;
  //Tell PHPMailer to use SMTP
  $mail->isSMTP();
  //Enable SMTP debugging
  // 0 = off (for production use)
  // 1 = client messages
  // 2 = client and server messages
  $mail->SMTPDebug = 0;
  //Set the hostname of the mail server
  $mail->Host = $mail_host;
  $mail->Port = $mail_port;
  //Set the encryption system to use - ssl (deprecated) or tls
  $mail->SMTPSecure = $smtp_secure;
  //Whether to use SMTP authentication
  $mail->SMTPAuth = true;
  //Username to use for SMTP authentication - use full email address for gmail
  $mail->Username = $mail_email;
  //Password to use for SMTP authentication
  $mail->Password = $mail_password;
  //Set who the message is to be sent from
  $mail->setFrom($mail_email, $mail_username);
  //Set who the message is to be sent to
  if (is_array($mail_destino)) {
    for ($i = 0; $i <= count($mail_destino); $i++) {
      $mail->addAddress($mail_destino[$i], $nombre_destino[$i]);
    }
  } else {
    $mail->addAddress($mail_destino, $nombre_destino);
  }
  //Set CCO
  if (is_array($mail_oculto)) {
    for ($i = 0; $i <= count($mail_oculto); $i++) {
      $mail->addBCC($mail_oculto[$i]);
    }
  } else {
    $mail->addBCC($mail_oculto);
  }

  //Set the subject line
  $mail->Subject = $asunto;
  $mail->IsHTML(true);
  $mail->CharSet = 'UTF-8';
  $mail->Body    = $mensaje;



  for ($i = 0; $i <= count($attachment); $i++) {
    $mail->AddAttachment($attachment[$i], $attachment_name[$i]);
  }
  if (!$mail->send()) {
    return "Mailer Error: " . $mail->ErrorInfo;
  } else {
    return "Message sent!";
  }
}

include_once("adminUsuarios.php");
$admin = new administradorUsuarios();
$correo = $_POST['correo'];
$fecha = $_POST['fecha'];
$token = rand(1, 8000000);
$idUSusario = $admin->existeUsuario($correo);
if ($idUSusario) {

  $mensaje = '<html><body>';
  $mensaje .= '<p>Para restablecer tu contraseña, haz click en el siguiente <a href="https://solomascotas.mx/account-login.php?tk=' . $token . '">enlace</a>
  <br> o tambien puedes acceder al siguiente enlace: https://solomascotas.mx/account-login.php?tk=' . $token . ' </p>';
  $mensaje .= '</body></html>';

  mailer($correo, $correo, "Recuperación de contraseña", $mensaje, "", "", "");

  $admin->insertaRecuperacion($idUSusario, $token, $fecha);
  // echo $idUSusario;
  // echo $correo;
  // echo $token;

  echo "1";
} else {
  echo "0";
}
