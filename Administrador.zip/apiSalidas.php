<?php 

$accion = $_POST['accion'];
$casoAgregar = "agregar";
$casoEliminar = "eliminar";
$casoModificar = "modificar";
$casoVerRegistros ="ver";
$casoVerUnRegistro  = "verUno";




function procesarImagen(){
  $ruta = 0;

  return $ruta;
}

function procesarAlta(){
  
}

function procesarBaja(){

}

function procesarVerRegistros(){

}

function procesarVerUnRegistro(){

}


switch($accion){
  case $casoAgregar:
    break;
  case $casoEliminar:
    break;
  case $casoVerRegistros:
    break;
  case $casoVerUnRegistro:
    break;
}

?>